#![no_std]
mod contract;
pub use crate::contract::Token;
